
/*
speaker => GURU, ZAREEM, TAHA, HULU, JONAH
face => FACE_NEUTRAL, FACE_HAPPY, FACE_SAD, FACE_UPSET, FACE_ANGRY, FACE_SHOCK
-- events will be added soon --
*/

const mission_five = [
    {
        speaker: GURU,
        text: "Hmmm, mission five dialogues are gonna be here!",
        face: FACE_NEUTRAL
        //event: ??? (coming soon)
    },
    {
        speaker: ZAREEM,
        text: "Okey tokey!",
        face: FACE_HAPPY
    }
];