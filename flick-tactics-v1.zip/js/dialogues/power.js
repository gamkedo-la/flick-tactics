
const powerDialogues = [
    {
        speaker: GURU,
        text: "I WILL NEVER GIVE UP!",
        face: FACE_HAPPY
    },
    {
        speaker: GURU,
        text: "When you think there's nothing left inside, I'll get up and keep trying!",
        face: FACE_HAPPY
    },
    {
        speaker: GURU,
        text: "I have some more moves left inside me!",
        face: FACE_HAPPY
    },
    {
        speaker: GURU,
        text: "I will fight to the very end!",
        face: FACE_HAPPY
    },

    {
        speaker: ZAREEM,
        text: "RIFLE MECHS TO ME!",
        face: FACE_HAPPY
    },
    {
        speaker: ZAREEM,
        text: "BRING OUT THE RIFLE MECHS!",
        face: FACE_HAPPY
    },
    {
        speaker: ZAREEM,
        text: "Time to overwhelm you with the BEST MECH! Rifle Mechs!",
        face: FACE_HAPPY
    },
    {
        speaker: ZAREEM,
        text: "BOOM BOOM! What do I hear? Rifle apocalypse.",
        face: FACE_HAPPY
    },

    {
        speaker: TAJA,
        text: "It's time for you to taste all my firepower!",
        face: FACE_HAPPY
    },
    {
        speaker: TAJA,
        text: "I'm going to destroy you with overwhelming force!",
        face: FACE_HAPPY
    },
    {
        speaker: TAJA,
        text: "MORE FIREPOWER!",
        face: FACE_HAPPY
    },
    {
        speaker: TAJA,
        text: "Time to wipe you off the map!",
        face: FACE_HAPPY
    },

    {
        speaker: HULU,
        text: "There is no hope for you.",
        face: FACE_HAPPY
    },
    {
        speaker: HULU,
        text: "You are walking towards defeat!",
        face: FACE_HAPPY
    },
    {
        speaker: HULU,
        text: "I will crush you!",
        face: FACE_HAPPY
    },
    {
        speaker: HULU,
        text: "Feel my WRATH!",
        face: FACE_HAPPY
    },

    {
        speaker: JONAH,
        text: "GIVE IT TO ME!",
        face: FACE_HAPPY
    },
    {
        speaker: JONAH,
        text: "What's mine is mine FOREVER",
        face: FACE_HAPPY
    },
    {
        speaker: JONAH,
        text: "COME JOIN YOUR TRUE MASTER!",
        face: FACE_HAPPY
    },
    {
        speaker: JONAH,
        text: "I only accept the strongest!",
        face: FACE_HAPPY
    },
];