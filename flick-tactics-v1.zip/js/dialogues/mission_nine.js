
/*
speaker => GURU, ZAREEM, TAHA, HULU, JONAH
face => FACE_NEUTRAL, FACE_HAPPY, FACE_SAD, FACE_UPSET, FACE_ANGRY, FACE_SHOCK
-- events will be added soon --
*/

const mission_nine = [
    {
        speaker: GURU,
        text: "Hmmm, mission nine dialogues are gonna be here!",
        face: FACE_NEUTRAL
        //event: ??? (coming soon)
    },
    {
        speaker: ZAREEM,
        text: "Okey tokey!",
        face: FACE_HAPPY
    }
];