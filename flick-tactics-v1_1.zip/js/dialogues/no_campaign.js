
const no_campaign = [
    {
        speaker: GURU,
        text: "Campaign is not added in the game yet.",
        face: FACE_HAPPY
    },
    {
        speaker: GURU,
        text: "But HEY! You can play Versus with your friends or AI.",
        face: FACE_HAPPY
    },
    {
        speaker: GURU,
        text: "Have fun!",
        face: FACE_HAPPY
    }
];