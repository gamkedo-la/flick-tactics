
const winDialogues = [
    {
        speaker: GURU,
        text: "Speed over costs, win the war.",
        face: FACE_HAPPY
    },
    {
        speaker: GURU,
        text: "The one who takes the initiative can strike first!",
        face: FACE_HAPPY
    },
    {
        speaker: GURU,
        text: "Haha, you were too slow!",
        face: FACE_HAPPY
    },
    {
        speaker: GURU,
        text: "I cannot let evil take this land.",
        face: FACE_HAPPY
    },

    {
        speaker: ZAREEM,
        text: "HA! YES! I'm getting stronger!",
        face: FACE_HAPPY
    },
    {
        speaker: ZAREEM,
        text: "Rifle Mechs all the way!",
        face: FACE_HAPPY
    },
    {
        speaker: ZAREEM,
        text: "I made Guru proud!",
        face: FACE_HAPPY
    },
    {
        speaker: ZAREEM,
        text: "I will protect the world!",
        face: FACE_HAPPY
    },

    {
        speaker: TAJA,
        text: "Ha! My Forces are Elite!",
        face: FACE_HAPPY
    },
    {
        speaker: TAJA,
        text: "I will become the supreme commander!",
        face: FACE_HAPPY
    },
    {
        speaker: TAJA,
        text: "Never get too close to the enemy! Take them out from afar!",
        face: FACE_HAPPY
    },
    {
        speaker: TAJA,
        text: "Artillery mechs will always be versatile.",
        face: FACE_HAPPY
    },

    {
        speaker: HULU,
        text: "Destory.... everything....",
        face: FACE_HAPPY
    },
    {
        speaker: HULU,
        text: "Scared of me? Hehe.",
        face: FACE_HAPPY
    },
    {
        speaker: HULU,
        text: "Fear me. Run, hide, I will still come for you.",
        face: FACE_HAPPY
    },
    {
        speaker: HULU,
        text: "FOR THE GLORY OF JONAH!",
        face: FACE_HAPPY
    },

    {
        speaker: JONAH,
        text: "This world belongs to me.",
        face: FACE_HAPPY
    },
    {
        speaker: JONAH,
        text: "I will take everything!",
        face: FACE_HAPPY
    },
    {
        speaker: JONAH,
        text: "What a useless bug you are!",
        face: FACE_HAPPY
    },
    {
        speaker: JONAH,
        text: "I enjoyed stepping on you.",
        face: FACE_HAPPY
    },
];